import java.util.Scanner;

class BankAccount {
    private double balance;

    public BankAccount(double initialBalance) {
        balance = Math.max(initialBalance, 0);
    }

    public void deposit(double amount) {
        if (amount > 0) balance += amount;
    }

    public boolean withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            return true;
        }
        return false;
    }

    public double getBalance() {
        return balance;
    }
}

public class ATM {
    private BankAccount account;
    private Scanner scanner;

    public ATM(BankAccount account) {
        this.account = account;
        this.scanner = new Scanner(System.in);
    }

    public void displayMenu() {
        int choice;
        do {
            System.out.println("\n--- ATM Menu ---");
            System.out.println("1. Withdraw");
            System.out.println("2. Deposit");
            System.out.println("3. Check Balance");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1: handleTransaction("withdraw"); break;
                case 2: handleTransaction("deposit"); break;
                case 3: System.out.println("Current Balance: $" + account.getBalance()); break;
                case 4: System.out.println("Exiting..."); break;
                default: System.out.println("Invalid choice.");
            }
        } while (choice != 4);
    }

    private void handleTransaction(String type) {
        System.out.print("Enter amount to " + type + ": ");
        double amount = scanner.nextDouble();
        if ("withdraw".equals(type)) {
            System.out.println(account.withdraw(amount) ? "Withdrawal successful." : "Insufficient balance.");
        } else {
            account.deposit(amount);
            System.out.println("Deposit successful.");
        }
    }

    public static void main(String[] args) {
        new ATM(new BankAccount(1000.00)).displayMenu(); 
    }
}
